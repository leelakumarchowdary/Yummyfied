import { Component } from '@angular/core';

@Component({
  selector: 'app-kitchen-management',
  templateUrl: './kitchen-management.component.html',
  styleUrl: './kitchen-management.component.scss'
})
export class KitchenManagementComponent {

}
